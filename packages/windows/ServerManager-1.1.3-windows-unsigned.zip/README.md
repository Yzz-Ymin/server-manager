# ServerManager

解压后执行 scripts/install.ps1，需要助手集成时添加 -InstallSkill。

运行开始菜单中的服务器管理。关闭窗口后驻留托盘；更新前先从托盘退出。

部分 Windows 自带扫描器的算法兼容问题会自动使用已安装 Git for Windows 的扫描器处理；没有可用兼容扫描器时请更新 Git 或 Windows OpenSSH。

连接元数据统一存于 %USERPROFILE%\.server-manager；首次启动迁移旧配置并保留源文件，密码仍保存在 Windows 凭据管理器。

需要 Windows 11、.NET Framework 4.8 和 OpenSSH 客户端，仅支持 Linux SSH 远端。

卸载时运行安装目录中的 uninstall.ps1，连接配置与凭据保留。

此为未签名开发构建。启用应用控制的主机可能拒绝运行；本地编译不会自动获得发布者信任。
